A program that shows the top 10 most populous countries as a pathetic bar chart with no axes.

Data: [United Nations World Population Prospects 2019](https://gist.github.com/curran/0ac4077c7fc6390f5dd33bf5c06cb5ff).